List of cars made with create-react-app
Using react-table with sorting, filtering and pagination.

Added delete functionality
- Delete button added in table rows (using row rendering)
- Calls fetch with DELETE method

Note! Install react-table
npm install --save react-table

Usage
create-react-app yourAppName
Replace the files found from the folder
